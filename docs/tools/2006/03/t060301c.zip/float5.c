/* float5.c 1.50 Demonstrate incommensurate floats with rounding and 
                 compiler surprises that are possible.  This program
                 also demonstrates the variability of controls and 
                 targets that can be appied using C++ compilers, some-
                 thing that can trip up the inexperienced and unwary.  
                 -- Dennis E. Hamilton, Seattle, 2006 March 23
                 */
                 
/* CONFIRM COMPILER ASSUMPTIONS AS WELL AS WE CAN 
   Because storage model and floating-point computation model impact
   this program, confirm as much as we can and warn against using
   in different cases that have not been anticipated.  We can't tell
   what all compiler options are, so force the behavior when we can
   and make a likely guess in other cases.
   
   This approach takes advantage of a valuable MSDN article on the
   improvements to the VC++ support for floating-point models.  It
   also provides useful insight into the subtleties of appropriate
   floating-point use in different circumstances:
   
   Fleegal, Eric. (2004)
       Microsoft Visual C++ Floating-Point Optimization.  Microsoft
       Corporation (Redmond, WA: June 2004).  Available on-line at
       <http://msdn.microsoft.com/library/en-us/dv_vstechart/html/floapoint.asp>
       (accessed 2006-04-23)
   */
#ifdef _MSC_VER
  #ifdef _M_IX86
    #pragma message("")
    #pragma message("Building in VC++ for Ix86 floating-point architecture.")
    #pragma message("This program depends on sizeof(char) being 1.")
    #if _MSC_VER > 1399
      #pragma message("Default floating-point option -fp:precise is used.")
      #pragma float_control(except, off)
      #pragma float_control(precise, on)
      #pragma fp_contract(on)
      #pragma fenv_access(off)
    #else
      #ifndef __STDC__
        #pragma message("Default non-precise option (/Op-) is presumed.")
      #else
        #pragma message("ANSI (/Za) precise-model default (/Op) is presumed.")
      #endif
    #endif
    #pragma message("")
  #else
    #pragma message("")
    #pragma message("This program has been developed to work for the Intel")
    #pragma message("Ix86 architecture implementation of IEEE float format.")
    #pragma message("It should be reviewed and adjusted for other processors.")
    #pragma message("")
    #error Review and adjust as needed for non-Ix86 processor architecture  
  #endif
#else
  #pragma message("")
  #pragma message("This program is specific to Microsoft VC++ and to")
  #pragma message("the Ix86 byte-order of float values.  It should be")
  #pragma message("reviewed and adjusted to work with different platforms.")
  #pragma message("")
  #error Review and adjust as needed before using with non-VC++ compiler
#endif


#include <stdio.h>
    /* for simple printf() usage. */

typedef union           
{   /* Use a union to access the bits of the Pentium float format,
       adapting an approach used by P. J. Plauger in "The Standard
       C Library," Prentice-Hall (Englewood Cliffs, NJ: 1992), p.65 */
            float f;                 /* A stored float value */
             char x[sizeof(float)];  /* viewed as sequence of bytes */
    } fp;
    
    
void showhex(char* var,  /* The name of the variable */ 
               fp* val   /* The value in a form for extraction */
                   )
{   /* Print the hexadecimal (big-endian) form of the float value */
    int i;
    
    printf("\n        %s is 0x", var);
    for (i = sizeof(float); i;)
         printf("%2.2X", val->x[--i] & 0xFF);    
    }                       


int main( )
{   /* Show how binary floating-point has many approximation differences
       that can surprise you in C/C++ programs. */

    fp r0, r1, r2, r3;

    printf("\nfloat5> 1.60 Demonstrating floating-point hiccups.\n");
    printf(  "        Microsoft (R) C/C++ Optimizing Compiler %.2f\n",
                      0.01 * _MSC_VER + 0.0049 );
    #if _MSC_VER < 1400
      #ifndef __STDC__                      
        printf("        Non-precise (/Op-) default model assumed.\n");
      #else
        printf("        ANSI (/Za) precise-model default (/Op) assumed.\n");
      #endif
    #else
      printf("        Precise floating-point model used.\n");
    #endif

    r0.f = 1.2;

    r1.f = 3.1;

    r2.f = 31.0;
   
    r3.f = 10.0 * r1.f;

    printf("\n        r0 is %f, r1 is %f, r2 is %f, and r3 is %f\n",
           r0.f, r1.f, r2.f, r3.f);
    printf(  "        where the r3 = 10.0 * r1 value printed might not\n");
    printf(  "        match the float value actually stored if the default\n");
    printf(  "        code optimization favors speed over consistency.\n");
  
    printf("\n        r1 * 10.0 is %f\n", r1.f * 10.0);
    printf(  "        the double value without rounding down to float.\n");

    printf("\n        r2 == r3 is %d\n", r2.f == r3.f);
    printf(  "        and r3 is rounded exact even though r1 can't be.\n");

    
    showhex("r0", &r0);    
    showhex("r1", &r1);
    printf("\n        both approximate with repeating bits to the end.\n");
    printf(  "        Output rounding has them appear to be exact.\n");
    
    showhex("r2", &r2);
    showhex("r3", &r3);
    printf("\n        both exact because r3 is rounded when stored.");
    printf("\n\n");

    return 0;
    } /* main */
    
/* RESULTS OBTAINED WITH DIFFERENT COMPILER DEFAULT SETTINGS

RESULTS: When this program is compiled with Visual C++ 2005 Express
Edition into a simple console application, execution of the program
produces the following output:
   
   float5> 1.60 Demonstrating floating-point hiccups.
           Microsoft (R) C/C++ Optimizing Compiler 14.00
           Precise floating-point model used.

           r0 is 1.200000, r1 is 3.100000, r2 is 31.000000, and r3 is 31.000000
           where the r3 = 10.0 * r1 value printed might not
           match the float value actually stored if the default
           code optimization favors speed over consistency.

           r1 * 10.0 is 30.999999
           the double value without rounding down to float.

           r2 == r3 is 1
           and r3 is rounded exact even though r1 can't be.

           r0 is 0x3F99999A
           r1 is 0x40466666
           both approximate with repeating bits to the end.
           Output rounding has them appear to be exact.

           r2 is 0x41F80000
           r3 is 0x41F80000
           both exact because r3 is rounded when stored.

All standard default options were used (that is, no special options were set).
   
When the Visual C++ Toolkit 2003 compiler is used, the first lines of the
output are
   
   float5> 1.60 Demonstrating floating-point hiccups.
           Microsoft (R) C/C++ Optimizing Compiler 13.10
           Non-precise (/Op-) default model assumed.

           r0 is 1.200000, r1 is 3.100000, r2 is 31.000000, and r3 is 30.999999

using the standard default options.  The remainder of the output is identical
to the VC++ 2005 Express result.
   
By requiring ANSI C rules, the following result is obtained:
   
   C:\MyProjects\float5>cl /Za float5.c
   Microsoft (R) 32-bit C/C++ Optimizing Compiler Version 13.10.3077 for 80x86
   Copyright (C) Microsoft Corporation 1984-2002. All rights reserved.

   float5.c

   Building in VC++ for Ix86 floating-point architecture.
   This program depends on sizeof(char) being 1.
   ANSI (/Za) precise-model default (/Op) is presumed.

   Microsoft (R) Incremental Linker Version 7.10.3077
   Copyright (C) Microsoft Corporation.  All rights reserved.

   /out:float5.exe
   float5.obj

   C:\MyProjects\float5>float5

   float5> 1.60 Demonstrating floating-point hiccups.
           Microsoft (R) C/C++ Optimizing Compiler 13.10
           ANSI (/Za) precise-model default (/Op) assumed.

           r0 is 1.200000, r1 is 3.100000, r2 is 31.000000, and r3 is 31.000000
           
and all further results are also identical to the VC++ 2005 Express output.
Although the outputs all appear acceptable, that is partly accomplished
by rounding the inexact internal values (e.g., r0 and r1) during output.
This means that the internal use of these values by the program must be
carefully managed by the programmer lest the approximations degrade to
the point that the visible results are impacted.   
   
*/    

/* 1.60 2006-03-23-15:18 Clean up presentation and add the expected output
        to the code as demonstration of what to expect.
   1.50 2006-03-23-14:27 Add compiler and options to the descriptions.
        Show impact of ANSI option (/Za) on pre-VS2005 floating-point.
   1.40 2006-03-23-13:28 Control optimization with pragmas where possible. 
        There is no complete provision for this prior to VC++ version 14.00.
   1.30 2006-03-23-12:11 Refactor the printing of float hex values.  Limit
        use of chars to ANSI-compliant forms.
   1.20 2006-03-23-10:08 Include conditional checks to make sure that
        we are using the correct compiler and platform for the assumed
        floating-point architecture and C Language implementation.
   1.10 2006-03-23-00:19 confirm identical results with VC++ 2005
        Express Edition.  Optimization level does not seem to matter
        with regard to r3 in the first printf() of the data.
   1.00 2006-03-22-22:11 initial version confirmed with the VC++ 
        Toolkit 2003 compiler.  This version shows a 3.099999 for the
        first output of r3 in the list of values.

   $Header: /MyProjects/Float5/float5.c 7     06-03-23 15:17 Orcmid $

/*                         end of float5.c                              */